package com.ada.econmerce.dominio.cliente.objetos;

public enum Tipo {
    FISICA,
    JURIDICA
}
