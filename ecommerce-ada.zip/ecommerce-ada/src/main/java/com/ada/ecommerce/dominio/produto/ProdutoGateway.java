package com.ada.ecommerce.dominio.produto;

import java.util.List;

public interface ProdutoGateway {

    void cadastrar(Produto produto);

    void atualizar(Integer id, Produto produto);

    Produto buscarPorId(Integer id);

    Produto buscarPorDescricao(String descricao);

    List<Produto> buscarTodos();

    Produto buscaPorMenorPreco();
}
