package com.ada.econmerce.dominio.pedido;

public enum Status {
    ABERTO, FECHADO, CANCELADO
}
