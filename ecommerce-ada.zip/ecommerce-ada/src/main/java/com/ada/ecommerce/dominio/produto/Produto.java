package com.ada.ecommerce.dominio.produto;

import java.math.BigDecimal;
import java.util.Objects;

public class Produto {

    private ProdutoID id;
    private String descricao;
    private BigDecimal preco;
    private Integer estoque;

    public Produto(ProdutoID id, String descricao, BigDecimal preco, Integer estoque) {
        this.id = id;
        this.descricao = descricao;
        this.preco = preco;
        this.estoque = estoque;

        this.validar();

    }

    public void alterarDescricao(String descricao) {
        if (this.descricao == null || this.descricao.isEmpty()){
            throw new IllegalArgumentException("A descrição não pode ser nulo ou vazia");
        }
        this.descricao = descricao;
    }

    public void alterarPreco(BigDecimal preco) {
        if (this.preco == null || preco.doubleValue() < 0){
            throw new IllegalArgumentException("O preço não pode ser nulo ou menor que zero");
        }
        this.preco = preco;
    }

    public void atualizarEstoque(Integer estoque) {
        if (this.estoque == null || estoque < 0){
            throw new IllegalArgumentException("O estoque não pode ser nulo ou menor que zero");
        }
        this.estoque += estoque;
    }

    public void diminuirEstoque(){
        if (this.estoque < 1 ){
            throw new RuntimeException("Estoque insuficiente");
        }
        this.estoque--;
    }

    public ProdutoID getId() {
        return id;
    }

    public String getDescricao() {
        return descricao;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public Integer getEstoque() {
        return estoque;
    }



    private void validar(){
        if (this.id == null){
            throw new IllegalArgumentException("O Id não pode ser nulo");
        }

        if (this.descricao == null || this.descricao.isEmpty()){
            throw new IllegalArgumentException("A descrição não pode ser nulo ou vazia");
        }

        if (this.preco == null || preco.doubleValue() < 0){
            throw new IllegalArgumentException("O preço não pode ser nulo ou menor que zero");
        }

        if (this.estoque == null || estoque < 0){
            throw new IllegalArgumentException("O estoque não pode ser nulo ou menor que zero");
        }
    }
}
