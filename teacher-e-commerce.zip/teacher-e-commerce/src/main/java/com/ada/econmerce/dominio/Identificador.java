package com.ada.econmerce.dominio;

public abstract class Identificador<T> {

    public abstract T valor();

}
