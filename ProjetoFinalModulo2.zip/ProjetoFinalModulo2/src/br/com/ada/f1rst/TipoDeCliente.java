package br.com.ada.f1rst;

public enum TipoDeCliente {
    PESSOAJURIDICA,
    PESSOAFISICA;
}
