package com.ada.locadora.dominio;

public abstract class Identificador<T> {

    public abstract T valor();

}
