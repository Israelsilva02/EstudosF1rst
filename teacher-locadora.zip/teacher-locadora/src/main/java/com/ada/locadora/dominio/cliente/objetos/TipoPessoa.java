package com.ada.locadora.dominio.cliente.objetos;

public enum TipoPessoa {
    FISICA,
    JURIDICA
}
