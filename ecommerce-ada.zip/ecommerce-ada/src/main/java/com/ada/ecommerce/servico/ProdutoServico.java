package com.ada.ecommerce.servico;

import com.ada.ecommerce.dominio.produto.Produto;
import com.ada.ecommerce.dominio.produto.ProdutoGateway;
import com.ada.ecommerce.dominio.produto.ProdutoID;

import java.math.BigDecimal;
import java.util.List;

public class ProdutoServico {

    private ProdutoGateway produtoGateway;

    public ProdutoServico(ProdutoGateway produtoGateway) {
        this.produtoGateway = produtoGateway;
    }

    public void incluir(String descricao, BigDecimal preco, Integer estoque){

        ProdutoID id = new ProdutoID();
        Produto produto = new Produto(id, descricao, preco, estoque);

        produtoGateway.cadastrar(produto);

    }

    public void atualizar(Integer id, String descricao, BigDecimal preco){

        Produto produtoAhAtualizar = produtoGateway.buscarPorId(id);

        produtoAhAtualizar.alterarDescricao(descricao);
        produtoAhAtualizar.alterarPreco(preco);

        produtoGateway.atualizar(id, produtoAhAtualizar);

    }

    public Produto buscarPorId(Integer id){
        return produtoGateway.buscarPorId(id);
    }

    public List<Produto> buscarTodos(){
        return produtoGateway.buscarTodos();
    }
}
