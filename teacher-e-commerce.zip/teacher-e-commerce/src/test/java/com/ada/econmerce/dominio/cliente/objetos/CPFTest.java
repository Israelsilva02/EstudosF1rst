package com.ada.econmerce.dominio.cliente.objetos;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CPFTest {

    @Test
    void dadoNumeroCPFValido_quandoChamarCriar_entaoDeveCriarUmCPF() {
       // Dado
        String id = "12345678900";

        // Quando
        CPF cpf = CPF.criar(id);

        // Então
        assertEquals(id, cpf.valor());
    }

    @Test
    void dadoNumeroCPFInvalido_quandoChamarCriar_entaoDeveLancarExcecao() {
        // Dado
        String id = "123456789";

        // Quando / Então
        assertThrows(IllegalArgumentException.class, () -> CPF.criar(id));
    }
}