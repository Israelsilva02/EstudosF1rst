package br.com.ada.livraria;

public class Membro {
    private String nome;

    public Membro(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
