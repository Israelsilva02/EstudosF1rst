package br.com.ada.f1rst;

public enum TipoDeConta {
    POUPANCA,
    CORRENTE,
    INVESTIMENTO,

}