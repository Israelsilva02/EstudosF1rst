package com.ada.ecommerce.infraestrutura;

import com.ada.ecommerce.dominio.produto.Produto;
import com.ada.ecommerce.dominio.produto.ProdutoGateway;

import java.util.ArrayList;
import java.util.List;

public class ProdutoRepositorioLista implements ProdutoGateway {

    private List<Produto> produtos = new ArrayList<>();

    @Override
    public void cadastrar(Produto produto) {
        produtos.add(produto);
    }

    @Override
    public void atualizar(Integer id, Produto produto) {
        Produto produtoAhRemover = buscarPorId(id);
        produtos.remove(produtoAhRemover);
        produtos.add(produto);
    }

    @Override
    public Produto buscarPorId(Integer id) {

        for(Produto produto : produtos){

            if (produto.getId().getValor().equals(id)){
                return produto;
            }
        }

        throw new RuntimeException("Produto não encontrado");
    }

    @Override
    public Produto buscarPorDescricao(String descricao) {

        for(Produto produto : produtos){

            if (produto.getDescricao().equals(descricao)){
                return produto;
            }
        }

        throw new RuntimeException("Produto não encontrado");
    }

    @Override
    public List<Produto> buscarTodos() {
        return produtos;
    }

    public Produto buscaPorMenorPreco(){
        // regra para buscar o produto de menor preco
        return null;
    }


}
