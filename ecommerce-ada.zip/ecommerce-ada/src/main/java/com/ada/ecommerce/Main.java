package com.ada.ecommerce;

import com.ada.ecommerce.dominio.cliente.CNPJ;
import com.ada.ecommerce.dominio.cliente.CPF;
import com.ada.ecommerce.dominio.cliente.Cliente;
import com.ada.ecommerce.dominio.cliente.ClienteGateway;
import com.ada.ecommerce.dominio.produto.ProdutoGateway;
import com.ada.ecommerce.infraestrutura.ClienteRepositorioLista;
import com.ada.ecommerce.infraestrutura.ProdutoRepositorioLista;
import com.ada.ecommerce.servico.ClienteServico;
import com.ada.ecommerce.servico.ProdutoServico;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ClienteGateway clienteGateway = new ClienteRepositorioLista();
        ClienteServico clienteServico = new ClienteServico(clienteGateway);

        ProdutoGateway produtoGateway = new ProdutoRepositorioLista();
        ProdutoServico produtoServico = new ProdutoServico(produtoGateway);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Selecione uma opção");
        String opcao = "";

        do {
            System.out.println("1-Cadastrar");
            System.out.println("2-Localizar");
            System.out.println("3-Alterar");
            System.out.println("4-Listar");

            System.out.println("---------------------------------");
            System.out.println("11-Cadastrar Produto");
            System.out.println("12-Localizar Produto");
            System.out.println("13-Alterar Produto");
            System.out.println("14-Listar Produto");
            System.out.println("---------------------------------");

            System.out.println("0-Finalizar");

            opcao = scanner.nextLine();
            System.out.println("Opção selecionada: " +opcao);
            switch (opcao) {
                case "1":
                    cadastrarCliente(scanner, clienteServico);
                    break;
                case "2":
                    localizarCliente(scanner, clienteServico);
                    break;
                case "3":
                    alterarCliente(scanner, clienteServico);
                    break;
                case "4":
                    listarCliente(clienteServico);
                    break;
                case "11":
                    cadastrarProduto(scanner, produtoServico);
                case "0":
                    System.out.println("Finalizando aplicação");
                    break;
                default:
                    System.out.println("Opção inválida");

                    break;
            }

        } while (!opcao.equals("0"));


    }

    private static void listarCliente(ClienteServico clienteServico) {
        //Listar todos os cliente
        System.out.println("Listando todos os clientes");
        List<Cliente> clientes = clienteServico.listarClientes();
        for (Cliente cliente : clientes) {
            System.out.print(cliente.getTipo() + ", ");
            System.out.print(cliente.getNome() + ", ");
            System.out.print(cliente.getEmail() + ", ");
            System.out.println(cliente.getEndereco());
        }
    }

    private static void alterarCliente(Scanner scanner, ClienteServico clienteServico) {
        System.out.println("Informe o CPF ou CNPJ");
        String cpfCnpjAlterar = scanner.nextLine();
        System.out.println("Informe o nome do cliente");
        String nomeAlterar = scanner.nextLine();
        System.out.println("Informe o nome do email");
        String emailAlterar = scanner.nextLine();
        System.out.println("Informe o endereco");
        String enderecoAlterar = scanner.nextLine();

        clienteServico.alterar(cpfCnpjAlterar, nomeAlterar, emailAlterar, enderecoAlterar);
        System.out.println("Cliente alterado com sucesso");
    }

    private static void localizarCliente(Scanner scanner, ClienteServico clienteServico) {
        //localizar um cliente por ID
        System.out.println("Informe o CPF ou CNPJ");
        String cpfCnpjLocalizar = scanner.nextLine();
        Cliente clienteLocalizado = clienteServico.localizarCliente(cpfCnpjLocalizar);
        System.out.println("Cliente localizado: ");
        System.out.print(clienteLocalizado.getTipo() + ", ");
        System.out.print(clienteLocalizado.getNome() + ", ");
        System.out.print(clienteLocalizado.getEmail() + ", ");
        System.out.println(clienteLocalizado.getEndereco());
    }

    private static void cadastrarCliente(Scanner scanner, ClienteServico clienteServico) {

        System.out.println("Informe o Tipo de Cliente PF ou PJ");
        String tipo = scanner.nextLine();
        System.out.println("Informe o CPF ou CNPJ");
        String cpfCnpj = scanner.nextLine();
        System.out.println("Informe o nome do cliente");
        String nome = scanner.nextLine();
        System.out.println("Informe o nome do email");
        String email = scanner.nextLine();
        System.out.println("Informe o endereco");
        String endereco = scanner.nextLine();

        Identificador identificador;
        if (tipo.equals("PF")) {
            identificador = new CPF(cpfCnpj);
        } else {
            identificador = new CNPJ(cpfCnpj);
        }
        clienteServico.incluir(identificador, nome, email, endereco);
        System.out.println("Cliente cadastrado com sucesso");
    }

    private static void cadastrarProduto(Scanner scanner, ProdutoServico produtoServico){
        System.out.println("Informe a descrição do produto");
        String descricao = scanner.nextLine();
        System.out.println("Informe o preco do produto (Ex: 10.00)");
        String preco = scanner.nextLine();
        System.out.println("Informe o estoque do produto");
        String estoque = scanner.nextLine();

        BigDecimal precoBigDecimal = new BigDecimal(preco);
        Integer estoqueInteger = Integer.parseInt(estoque);

        produtoServico.incluir(descricao, precoBigDecimal, estoqueInteger );

    }

}