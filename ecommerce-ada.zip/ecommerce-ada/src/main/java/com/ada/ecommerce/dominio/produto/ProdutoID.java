package com.ada.ecommerce.dominio.produto;

import com.ada.ecommerce.Identificador;

public class ProdutoID extends Identificador<Integer> {

    private static Integer id = 0;
    private Integer numero;

    public ProdutoID(){
        ProdutoID.id++;
        this.numero = ProdutoID.id;
    }

    @Override
    public Integer getValor() {
        return numero;
    }

    @Override
    public String nome() {
        return "ProdutoID";
    }
}
